module Main where

import Dragons.Main

main :: IO ()
main = appMain
