{-|
Module      : AITests
Description : Tests for your AI functions
Copyright   : (c) 2020 Your Name Here
License     : AllRightsReserved
-}
module AITests where

import           AI
import           Othello
import           Testing

aiTests :: Test
aiTests = TestGroup "AI"
  [
  ]
