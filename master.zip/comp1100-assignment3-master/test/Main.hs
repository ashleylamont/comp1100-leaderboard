module Main where

import Dragons.TestMain

main :: IO ()
main = testMain
